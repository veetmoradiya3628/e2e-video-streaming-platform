
    ____________                          
   / ____/ ____/___ ___  ____  ___  ____ _
  / /_  / /_  / __ `__ \/ __ \/ _ \/ __ `/
 / __/ / __/ / / / / / / /_/ /  __/ /_/ / 
/_/   /_/   /_/ /_/ /_/ .___/\___/\__, /  
                     /_/         /____/   

Build version: nightly-2017-11-26
Build date: Sun Nov 26 23:27:43 UTC 2017

ffmpeg version N-89248-g3701d499f8 Copyright (c) 2000-2017 the FFmpeg developers
built with gcc 6.3.0 (Debian 6.3.0-18) 20170516
configuration: --cc=gcc-6 --prefix=/tmp/ffmpeg_build --pkg-config-flags=--static --extra-cflags='-I/tmp/ffmpeg_build/include -static' --extra-ldflags='-L/tmp/ffmpeg_build/lib -static' --extra-libs='-lpthread -lm' --bindir=/opt/ffmpeg/bin --cpu=sandybridge --arch=x84_64 --disable-shared --enable-static --disable-debug --disable-runtime-cpudetect --disable-ffplay --disable-ffserver --disable-doc --disable-network --disable-devices --disable-protocols --enable-protocol=file --enable-protocol=pipe --enable-protocol=tee --enable-libmp3lame --enable-libvpx --enable-libwebp --enable-libopus --enable-fontconfig --enable-gray --enable-libfreetype --enable-libopenjpeg --enable-libspeex --enable-libtheora --enable-libvorbis --enable-libfribidi --enable-gpl --enable-frei0r --enable-libx264 --enable-libx265 --enable-libxvid --enable-version3 --enable-libopencore-amrnb --enable-libopencore-amrwb --enable-libvo-amrwbenc
libavutil      56.  3.100 / 56.  3.100
libavcodec     58.  3.105 / 58.  3.105
libavformat    58.  2.102 / 58.  2.102
libavdevice    58.  0.100 / 58.  0.100
libavfilter     7.  4.100 /  7.  4.100
libswscale      5.  0.101 /  5.  0.101
libswresample   3.  0.101 /  3.  0.101
libpostproc    55.  0.100 / 55.  0.100

This build of FFmpeg is licensed under the GPLv3. See the source code for details.

The source code can be downloaded from https://github.com/binoculars/ffmpeg-build-lambda/releases/tag/nightly-2017-11-26

